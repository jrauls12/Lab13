﻿using System;
class Program
{
    static void Main()
    {
        string[] nom = new string[5];
        double[] edades = new double[5];
        double edadmayor = 0;
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine("Ingrese los nombres de las personas");
            nom[i] = Console.ReadLine();
            Console.WriteLine("Ingrese las edades de las personas ");
            edades[i] = int.Parse(Console.ReadLine());
        }
        for (int i = 0; i < 5; i++)
        {
            if (edades[i] >= 18)
            {
                Console.WriteLine("las perosnas con mayor edad son" + nom[i] + "con" + edades[i]);
            }
            if (edades[i] <= 18)
            {
                Console.WriteLine("las perosnas con menor de edad son" + nom[i] + "con" + edades[i]);
            }
        }
    }
}